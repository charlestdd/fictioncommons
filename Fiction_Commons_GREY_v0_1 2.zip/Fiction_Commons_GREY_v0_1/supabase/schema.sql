-- FICTION COMMONS / GREY v0.1
-- Run this in Supabase SQL Editor.

create extension if not exists pgcrypto;

create table if not exists public.applications (
  id uuid primary key default gen_random_uuid(),
  email text not null unique,
  nickname text not null,
  contribution_types text[] not null default '{}',
  status text not null default 'pending'
    check (status in ('pending','approved','rejected')),
  assigned_username text,
  created_at timestamptz not null default now(),
  reviewed_at timestamptz
);

create table if not exists public.profiles (
  id uuid primary key,
  email text not null unique,
  username text unique,
  nickname text not null,
  ownership_units numeric(5,2) not null default 0.00
    check (ownership_units >= 0 and ownership_units <= 5.00),
  created_at timestamptz not null default now()
);

alter table public.applications enable row level security;
alter table public.profiles enable row level security;

-- Public registration: allow anonymous inserts only.
create policy "Anyone can submit an application"
on public.applications
for insert
to anon
with check (
  status = 'pending'
  and reviewed_at is null
);

-- Public homepage statistics need counts. This prototype uses a controlled view.
create or replace view public.public_application_stats as
select
  count(*)::int as registered,
  count(*) filter (where status = 'approved')::int as approved,
  count(*) filter (where status = 'pending')::int as pending
from public.applications;

-- IMPORTANT:
-- The admin dashboard in this prototype uses browser-side admin credentials only
-- because this is an MVP. That is NOT secure for production.
-- For a real deployment, admin operations must move to a server/Edge Function
-- using a secret service-role key, and the admin password must never be committed
-- to a public repository.

-- For the first prototype, you can temporarily use development policies while testing.
-- Replace these with proper authenticated/admin policies before public launch.
